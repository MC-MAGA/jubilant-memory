<?php

function wp_mail( $to, $subject, $message, $headers = '', $attachments = array() ){
	return __return_false();
}

function gh_mail( $to, $subject, $message, $headers = '', $attachments = array() ){
	return __return_false();
}
