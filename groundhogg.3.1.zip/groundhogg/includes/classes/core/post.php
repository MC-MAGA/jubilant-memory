<?php

namespace Groundhogg\Classes\Core;

use Groundhogg\Base_Object_With_Meta_Interface;

class Post implements Base_Object_With_Meta_Interface {

	public function exists() {
		// TODO: Implement exists() method.
	}

	public function get_id() {
		// TODO: Implement get_id() method.
	}

	public function get_object_type() {
		// TODO: Implement get_object_type() method.
	}

	public function update( $data = [] ) {
		// TODO: Implement update() method.
	}

	public function delete() {
		// TODO: Implement delete() method.
	}

	public function get_all_meta() {
		// TODO: Implement get_all_meta() method.
	}

	public function get_meta( $key = false, $single = true ) {
		// TODO: Implement get_meta() method.
	}

	public function add_meta( $key, $value = true ) {
		// TODO: Implement add_meta() method.
	}

	public function update_meta_if_empty( $key, $value = false ) {
		// TODO: Implement update_meta_if_empty() method.
	}

	public function update_meta( $key, $value = false ) {
		// TODO: Implement update_meta() method.
	}

	public function delete_meta( $key ) {
		// TODO: Implement delete_meta() method.
	}
}
