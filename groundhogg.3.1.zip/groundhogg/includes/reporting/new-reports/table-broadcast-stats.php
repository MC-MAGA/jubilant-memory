<?php

namespace Groundhogg\Reporting\New_Reports;


use Groundhogg\Broadcast;
use Groundhogg\Classes\Activity;
use Groundhogg\Event;
use Groundhogg\Plugin;
use function Groundhogg\_nf;
use function Groundhogg\admin_page_url;
use function Groundhogg\convert_to_local_time;
use function Groundhogg\get_array_var;
use function Groundhogg\get_date_time_format;
use function Groundhogg\get_db;
use function Groundhogg\get_request_var;
use function Groundhogg\html;
use function Groundhogg\key_to_words;
use function Groundhogg\percentage;

class Table_Broadcast_Stats extends Base_Table_Report {

	/**
	 * @return mixed
	 */
	protected function get_broadcast_id() {
		$id = absint( get_array_var( get_request_var( 'data', [] ), 'broadcast_id' ) );

		if ( ! $id ) {

			$broadcasts = get_db( 'broadcasts' )->query( [
				'status'  => 'sent',
				'orderby' => 'send_time',
				'order'   => 'desc',
				'limit'   => 1
			] );

			if ( ! empty( $broadcasts ) ) {
				$id = absint( array_shift( $broadcasts )->ID );
			}
		}

		return $id;
	}

	protected function get_table_data() {

		$broadcast = new Broadcast( $this->get_broadcast_id() );

		if ( ! $broadcast->exists() ) {
			return [];
		}

		$stats = $broadcast->get_report_data();

		$title  = $broadcast->is_email() ? $broadcast->get_object()->get_subject_line() : $broadcast->get_title();
		$object = $broadcast->get_object();

		return [
			[
				'label' => __( 'Subject', 'groundhogg' ),
				'data'  => $broadcast->is_email() ? html()->wrap( $title, 'a', [
					'href'  => admin_page_url( 'gh_emails', [
						'action' => 'edit',
						'email'  => $object->get_id()
					] ),
					'title' => $title,
				] ) : $title
			],
			[
				'label' => __( 'Sent', 'groundhogg' ),
				'data'  => date_i18n( get_date_time_format(), convert_to_local_time( $broadcast->get_send_time() ) ),
			],
			[
				'label' => __( 'Total Delivered', 'groundhogg' ),
				'data'  => html()->wrap( _nf( $stats['sent'] ), 'a', [
					'href'  => add_query_arg(
						[
							'report' => [
								'type'   => Event::BROADCAST,
								'step'   => $broadcast->get_id(),
								'status' => Event::COMPLETE
							]
						],
						admin_page_url( 'gh_contacts' )
					),
					'class' => 'number-total'
				] )
			],
			$broadcast->is_sms() ? false : [
				'label' => __( 'Opens', 'groundhogg' ),
				'data'  => html()->wrap( _nf( $stats['opened'] ) . ' (' . percentage( $stats['sent'], $stats['opened'] ) . '%)', 'a', [
					'href'  => add_query_arg(
						[
							'activity' => [
								'activity_type' => Activity::EMAIL_OPENED,
								'step_id'       => $broadcast->get_id(),
								'funnel_id'     => $broadcast->get_funnel_id()
							]
						],
						admin_url( sprintf( 'admin.php?page=gh_contacts' ) )
					),
					'class' => 'number-total'
				] )
			],
			[
				'label' => __( 'Total Clicks', 'groundhogg' ),
				'data'  => html()->wrap( _nf( $stats['all_clicks'] ), 'span', [
					'class' => 'number-total'
				] )
			],
			[
				'label' => __( 'Unique Clicks', 'groundhogg' ),
				'data'  => html()->wrap( _nf( $stats['clicked'] ) . ' (' . percentage( $stats['sent'], $stats['clicked'] ) . '%)', 'a', [
					'href'  => add_query_arg(
						[
							'activity' => [
								'activity_type' => $broadcast->is_sms() ? Activity::SMS_CLICKED : Activity::EMAIL_CLICKED,
								'step_id'       => $broadcast->get_id(),
								'funnel_id'     => $broadcast->get_funnel_id()
							]
						],
						admin_url( sprintf( 'admin.php?page=gh_contacts' ) )
					),
					'class' => 'number-total'
				] )
			],
			[
				'label' => __( 'Click Thru Rate', 'groundhogg' ),
				'data'  => percentage( $stats[ $broadcast->is_sms() ? 'sent' : 'opened'], $stats['clicked'] ) . '%'
			],
			$broadcast->is_sms() ? false : [
				'label' => __( 'Unopened', 'groundhogg' ),
				'data'  => _nf( $stats['unopened'] ) . ' (' . percentage( $stats['sent'], $stats['unopened'] ) . '%)'
			],
			[
				'label' => __( 'Unsubscribed', 'groundhogg' ),
				'data'  => html()->wrap( _nf( $stats['unsubscribed'] ) . ' (' . percentage( $stats['sent'], $stats['unsubscribed'] ) . '%)', 'a', [
					'href'  => add_query_arg(
						[
							'activity' => [
								'activity_type' => Activity::UNSUBSCRIBED,
								'step_id'       => $broadcast->get_id(),
								'funnel_id'     => $broadcast->get_funnel_id()
							]
						],
						admin_url( sprintf( 'admin.php?page=gh_contacts' ) )
					),
					'class' => 'number-total'
				] )
			],

		];

	}

	protected function normalize_datum( $item_key, $item_data ) {
		// TODO: Implement normalize_datum() method.
	}

	function get_label() {
		return [];
	}
}
