<?php

namespace Groundhogg\Admin\Funnels;

use Groundhogg\Admin\Admin_Page;
use Groundhogg\Contact_Query;
use Groundhogg\Funnel;
use Groundhogg\Library;
use Groundhogg\Plugin;
use Groundhogg\Step;
use function Groundhogg\add_disable_emojis_action;
use function Groundhogg\admin_page_url;
use function Groundhogg\download_json;
use function Groundhogg\enqueue_email_block_editor_assets;
use function Groundhogg\enqueue_groundhogg_modal;
use function Groundhogg\get_array_var;
use function Groundhogg\get_contactdata;
use function Groundhogg\get_db;
use function Groundhogg\get_post_var;
use function Groundhogg\get_request_var;
use function Groundhogg\get_store_products;
use function Groundhogg\get_upload_wp_error;
use function Groundhogg\get_url_var;
use function Groundhogg\html;
use function Groundhogg\notices;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * View Funnels
 *
 * Allow the user to view & edit the funnels
 *
 * @since       0.1
 * @subpackage  Includes/Funnels
 * @copyright   Copyright (c) 2018, Adrian Tobey
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     groundhogg
 */
class Funnels_Page extends Admin_Page {

	protected function get_current_action() {
		$action = parent::get_current_action();

		if ( $action === 'view' && get_db( 'funnels' )->is_empty() ) {
			$action = 'add';
		}

		return $action;
	}

	protected function add_ajax_actions() {
		add_action( 'wp_ajax_gh_get_templates', [ $this, 'get_funnel_templates_ajax' ] );

		add_action( 'wp_ajax_wpgh_get_step_html', [ $this, 'add_step' ] );
		add_action( 'wp_ajax_gh_save_funnel_via_ajax', [ $this, 'ajax_save_funnel' ] );
		add_action( 'wp_ajax_wpgh_duplicate_funnel_step', [ $this, 'duplicate_step' ] );

		add_action( 'wp_ajax_gh_funnel_editor_full_screen_preference', [
			$this,
			'update_user_full_screen_preference'
		] );
	}

	/**
	 * Whether the editor should appear full screen or not
	 *
	 * @return void
	 */
	function update_user_full_screen_preference() {
		$is_full_screen = filter_var( get_post_var( 'full_screen', false ), FILTER_VALIDATE_BOOLEAN );
		update_user_meta( get_current_user_id(), 'gh_funnel_editor_full_screen', $is_full_screen );

		wp_send_json( $is_full_screen );
	}

	public function admin_title( $admin_title, $title ) {
		switch ( $this->get_current_action() ) {
			case 'add':
				$admin_title = sprintf( "%s &lsaquo; %s", __( 'Add' ), $admin_title );
				break;
			case 'edit':
				$funnel_id = get_request_var( 'funnel' );
				$funnel    = new Funnel( absint( $funnel_id ) );

				if ( $funnel->exists() ) {
					$admin_title = sprintf( "%s &lsaquo; %s &lsaquo; %s", $funnel->get_title(), __( 'Edit' ), $admin_title );
				}

				break;
		}

		return $admin_title;
	}

	/**
	 * Get the current screen title based on the action
	 */
	public function get_title() {
		switch ( $this->get_current_action() ) {
			case 'add':
				return _ex( 'Add Funnel', 'page_title', 'groundhogg' );
				break;
			case 'edit':
				return _ex( 'Edit Funnel', 'page_title', 'groundhogg' );
				break;
			case 'view':
			default:
				return _ex( 'Funnels', 'page_title', 'groundhogg' );
		}
	}

	/**
	 * Redirect to the add screen if no funnels are present.
	 */
	public function redirect_to_add() {
		if ( get_db( 'funnels' )->count() == 0 ) {
			die( wp_redirect( $this->admin_url( [ 'action' => 'add' ] ) ) );
		}
	}

	protected function add_additional_actions() {

		add_disable_emojis_action();

		if ( $this->is_current_page() && $this->get_current_action() === 'edit' ) {
			add_action( 'in_admin_header', array( $this, 'prevent_notices' ) );
			/* just need to enqueue it... */
			enqueue_groundhogg_modal();
		}

		add_action( "groundhogg/admin/gh_funnels/before", function () {
			if ( get_db( 'funnels' )->exists( [ 'status' => 'inactive' ] ) && ! get_db( 'funnels' )->exists( [ 'status' => 'active' ] ) ) {
				notices()->add( 'no_active_funnels', sprintf( '%s %s', __( 'You have no active funnels.' ), html()->e( 'a', [
					'href' => admin_url( 'admin.php?page=gh_funnels&status=inactive' ),
				], __( 'Activate a funnel!' ) ) ), 'warning' );
			}
		} );
	}

	public function get_slug() {
		return 'gh_funnels';
	}

	public function get_name() {
		return _x( 'Funnels', 'page_title', 'groundhogg' );
	}

	public function get_cap() {
		return 'edit_funnels';
	}

	public function get_item_type() {
		return 'funnel';
	}

	public function get_priority() {
		return 30;
	}

	/**
	 * enqueue editor scripts
	 */
	public function scripts() {

		switch ( $this->get_current_action() ) {
			case 'edit':

				wp_enqueue_editor();

				wp_enqueue_style( 'editor-buttons' );
				wp_enqueue_style( 'jquery-ui' );

				wp_enqueue_script( 'wplink' );

				wp_enqueue_script( 'jquery-ui-sortable' );
				wp_enqueue_script( 'jquery-ui-draggable' );
				$funnel = new Funnel( get_url_var( 'funnel' ) );

				wp_enqueue_style( 'groundhogg-admin-funnel-editor' );
				wp_enqueue_script( 'groundhogg-admin-funnel-editor' );
				wp_localize_script( 'groundhogg-admin-funnel-editor', 'Funnel', [
					'steps'      => $funnel->get_steps(),
					'id'         => absint( get_request_var( 'funnel' ) ),
					'save_text'  => __( 'Update', 'groundhogg' ),
					'export_url' => $funnel->export_url(),
					'is_active'  => $funnel->is_active()
				] );

				wp_enqueue_script( 'groundhogg-admin-replacements' );
				wp_enqueue_script( 'groundhogg-admin-funnel-steps' );

				add_filter( 'admin_body_class', function ( $class ) {

					$is_full_screen = get_user_meta( get_current_user_id(), 'gh_funnel_editor_full_screen', true );

					if ( $is_full_screen ) {
						$class .= ' funnel-full-screen';
					}

					return $class;
				} );

				enqueue_email_block_editor_assets();

				do_action( 'groundhogg/admin/funnels/editor_scripts' );

				break;
			case 'add':
				wp_enqueue_style( 'groundhogg-admin-element' );
				break;
		}

		wp_enqueue_style( 'groundhogg-admin' );
	}

	public function help() {
		$screen = get_current_screen();

		$screen->add_help_tab(
			array(
				'id'      => 'gh_overview',
				'title'   => __( 'Overview' ),
				'content' => '<p>' . __( 'Here you can edit your funnels. A funnel is a set of steps which can run automation based on contact interactions with your site. You can view the number of active contacts in each funnel, as well as when it was created and last updated.', 'groundhogg' ) . '</p>'
				             . '<p>' . __( 'Funnels can be either Active/Inactive/Archived. If a funnel is Inactive, no contacts can enter and any contacts that may have been in the funnel will stop moving forward. The same goes for Archived funnels which simply do not show in the main list.', 'groundhogg' ) . '</p>'
			)
		);

		$screen->add_help_tab(
			array(
				'id'      => 'gh_add',
				'title'   => __( 'Add A Funnel' ),
				'content' => '<p>' . __( 'To create a new funnel, simply click the Add New Button in the top left and select a pre-built funnel template. If you have a funnel import file you can click the import tab and upload the funnel file which will auto generate a funnel for you.', 'groundhogg' ) . '</p>'
			)
		);

		$screen->add_help_tab(
			array(
				'id'      => 'gh_edit',
				'title'   => __( 'Editing' ),
				'content' => '<p>' . __( 'When editing a funnel you can add Funnel Steps. Funnel Steps are either Benchmarks or Actions. Benchmarks are whenever a Contact "does" something, while Actions are doing thing to a contact such as sending an email. Simply drag in the desired funnel steps in any order.', 'groundhogg' ) . '</p>'
				             . '<p>' . __( 'Actions are run sequentially, so when an action takes place, it simply loads the next action. That means if you need to change it you can!', 'groundhogg' ) . '</p>'
				             . '<p>' . __( 'Benchmarks are a bit different. If you have several benchmarks in a row, what happens is once one of them is completed by a contact the first action found proceeding that benchmark is launched, skipping all other benchmarks. That way you can have multiple automation triggers. ', 'groundhogg' ) . '</p>'
				             . '<p>' . __( 'Once a benchmark is complete all steps that are scheduled before that benchmark will stop immediately.', 'groundhogg' ) . '</p>'
			)
		);

	}

	public function process_delete() {
		if ( ! current_user_can( 'delete_funnels' ) ) {
			$this->wp_die_no_access();
		}

		foreach ( $this->get_items() as $id ) {
			$funnel = new Funnel( $id );

			if ( ! $funnel->exists() ) {
				continue;
			}

			$funnel->delete();
		}

		$this->add_notice(
			esc_attr( 'deleted' ),
			sprintf( _nx( 'Deleted %d funnel', 'Deleted %d funnels', count( $this->get_items() ), 'notice', 'groundhogg' ), count( $this->get_items() ) ),
			'success'
		);

		return false;
	}

	/**
	 * Update the current funnels to a specific status
	 *
	 * @param $status
	 *
	 * @return int
	 */
	public function update_funnels_status( $status ) {

		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		$updated = 0;

		foreach ( $this->get_items() as $id ) {
			$funnel = new Funnel( $id );

			if ( ! $funnel->exists() ) {
				continue;
			}

			if ( $funnel->update( [
				'status' => $status
			] ) ) {
				$updated ++;
			}
		}

		return $updated;
	}

	/**
	 * Restore a funnel
	 *
	 * @return void
	 */
	public function process_restore() {
		$updated = $this->update_funnels_status( 'inactive' );

		$this->add_notice(
			esc_attr( 'restored' ),
			sprintf( _nx( 'Restored %d funnel', 'Restored %d funnels', $updated, 'notice', 'groundhogg' ), $updated ),
			'success'
		);
	}

	/**
	 * Archive a funnel
	 *
	 * @return void
	 */
	public function process_archive() {
		$updated = $this->update_funnels_status( 'archived' );

		$this->add_notice(
			esc_attr( 'archived' ),
			sprintf( _nx( 'Archived %d funnel', 'Archived %d funnels', $updated, 'notice', 'groundhogg' ), $updated ),
			'success'
		);
	}

	/**
	 * Deactivate a funnel
	 *
	 * @return void
	 */
	public function process_deactivate() {
		$updated = $this->update_funnels_status( 'inactive' );

		$this->add_notice(
			esc_attr( 'deactivated' ),
			sprintf( _nx( 'Deactivated %d funnel', 'Deactivated %d funnels', $updated, 'notice', 'groundhogg' ), $updated ),
			'success'
		);
	}

	/**
	 * Activate a funnel
	 *
	 * @return void
	 */
	public function process_activate() {
		$updated = $this->update_funnels_status( 'active' );

		$this->add_notice(
			esc_attr( 'activated' ),
			sprintf( _nx( 'Activated %d funnel', 'Activated %d funnels', $updated, 'notice', 'groundhogg' ), $updated ),
			'success'
		);
	}

	/**
	 * Duplicate a funnel
	 *
	 * @return false|string
	 */
	public function process_duplicate() {

		if ( ! current_user_can( 'add_funnels' ) ) {
			$this->wp_die_no_access();
		}

		foreach ( $this->get_items() as $id ) {

			$funnel = new Funnel( $id );

			if ( ! $funnel->exists() ) {
				continue;
			}

			$json = $funnel->export();

			$new_funnel = new Funnel();
			$id         = $new_funnel->import( $json );

			$new_funnel->update( [
				'title' => sprintf( __( 'Copy of %s', 'groundhogg' ), $funnel->get_title() ),
			] );

			return $this->admin_url( [ 'action' => 'edit', 'funnel' => $id ] );
		}

		return false;
	}

	/**
	 * Export a list of funnels
	 *
	 * @return void
	 */
	public function process_export() {

		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		$funnels = [];

		foreach ( $this->get_items() as $item ) {
			$funnel    = new Funnel( $item );
			$funnels[] = $funnel->export();
		}

		download_json( $funnels, 'funnels' );
	}

	/**
	 * Create a new funnel without using a template
	 *
	 * @return string
	 */
	public function process_start_from_scratch() {
		if ( ! current_user_can( 'add_funnels' ) ) {
			$this->wp_die_no_access();
		}

		$funnel = new Funnel();
		$funnel->create( [
			'title'  => 'My new funnel',
			'author' => get_current_user_id(),
			'status' => 'inactive',
		] );

		return $funnel->admin_link();
	}

	/**
	 * Process add action for the funnel.
	 *
	 * @return string|\WP_Error
	 */
	public function process_add() {

		if ( ! current_user_can( 'add_funnels' ) ) {
			$this->wp_die_no_access();
		}

		$funnel_id = false;

		if ( isset( $_POST['funnel_template'] ) ) {

			$template_id = get_request_var( 'funnel_template' );
			$library     = new Library();
			$template    = $library->get_funnel_template( $template_id );
			$funnel_id   = $this->import_funnel( $template );

		} else if ( isset( $_POST['funnel_id'] ) ) {

			$from_funnel = absint( get_request_var( 'funnel_id' ) );
			$from_funnel = new Funnel( $from_funnel );

			$json      = $from_funnel->export();
			$funnel_id = $this->import_funnel( $json );

		} else if ( isset( $_FILES['funnel_template'] ) ) {
			$file = get_array_var( $_FILES, 'funnel_template' );

			$file = map_deep( $file, 'sanitize_text_field' );

			$error = get_upload_wp_error( $file );

			if ( is_wp_error( $error ) ) {
				return $error;
			}

			$validate = wp_check_filetype( $file['name'], [
				'funnel' => 'text/plain',
				'json'   => 'application/json',
			] );

			if ( ! in_array( $validate['ext'], [ 'json', 'funnel' ] ) ) {
				return new \WP_Error( 'invalid_template', __( 'Please upload a valid funnel template.', 'groundhogg' ) );
			}

			$json = file_get_contents( $file['tmp_name'] );
			$json = json_decode( $json );

			if ( ! $json ) {
				return new \WP_Error( 'invalid_json', 'Funnel template has invalid JSON.' );
			}

			// Importing multiple funnels
			if ( is_array( $json ) ) {

				foreach ( $json as $funnel ) {
					$this->import_funnel( $funnel );
				}

				$this->add_notice( 'imported', sprintf( __( 'Imported %d funnels', 'groundhogg' ), count( $json ) ) );

				return admin_page_url( 'gh_funnels', [ 'view' => 'inactive' ] );
			}

			$funnel_id = $this->import_funnel( $json );

		} else if ( $json = get_request_var( 'funnel_json' ) ) {

			$json = json_decode( $json );

			if ( ! $json ) {
				return new \WP_Error( 'invalid_json', 'Invalid JSON provided.' );
			}

			// Importing multiple funnels
			if ( is_array( $json ) ) {

				foreach ( $json as $funnel ) {
					$this->import_funnel( $funnel );
				}

				$this->add_notice( 'imported', sprintf( __( 'Imported %d funnels', 'groundhogg' ), count( $json ) ) );

				return admin_page_url( 'gh_funnels', [ 'view' => 'inactive' ] );
			}

			$funnel_id = $this->import_funnel( $json );
		}

		if ( is_wp_error( $funnel_id ) ) {
			return $funnel_id;
		}

		if ( empty( $funnel_id ) ) {
			return new \WP_Error( 'error', __( 'Could not create funnel.', 'groundhogg' ) );
		}

		return admin_page_url( 'gh_funnels', [
			'action' => 'edit',
			'funnel' => $funnel_id
		] );

	}

	/**
	 * Deconstructs the given array and builds a full funnel.
	 *
	 * @param $import array|string
	 *
	 * @return bool|int whether the import was successful or the ID
	 */
	public function import_funnel( $import = array() ) {

		if ( ! current_user_can( 'import_funnels' ) ) {
			$this->wp_die_no_access();
		}

		$funnel = new Funnel();

		return $funnel->import( $import );
	}

	/**
	 * Save the funnel via ajax...
	 */
	public function ajax_save_funnel() {
		if ( ! wp_doing_ajax() ) {
			return;
		}

		if ( ! $this->verify_action() ) {
			wp_send_json_error();
		}

		$result = $this->process_edit();

		if ( is_wp_error( $result ) ) {
			$this->add_notice( $result );
		}

		$result = [];

		$result['settings'] = $this->get_step_html();
		$result['sortable'] = $this->get_step_sortable();
		$result['steps']    = $this->get_current_funnel()->get_steps();

		$this->send_ajax_response( $result );

	}

	public function get_step_html() {
		$funnel = $this->get_current_funnel();
		$steps  = $funnel->get_steps();

		$html = "";

		foreach ( $steps as $step ) {

			ob_start();
			$step->html_v2();
			$html .= ob_get_clean();

		}

		return $html;
	}

	/**
	 * @return Funnel
	 */
	public function get_current_funnel() {
		return new Funnel( absint( get_request_var( 'funnel' ) ) );
	}

	public function get_step_sortable() {
		$funnel = $this->get_current_funnel();
		$steps  = $funnel->get_steps();

		$html = "";

		foreach ( $steps as $step ) {
			ob_start();
			$step->sortable_item();
			$html .= ob_get_clean();
		}

		return $html;
	}

	/**
	 * Save the funnel
	 */
	public function process_edit() {

		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		if ( get_request_var( '_delete_step' ) ) {

			$step_id = absint( get_request_var( '_delete_step' ) );
			$step    = new Step( $step_id );

			if ( ! $step->exists() ) {
				wp_send_json_error();
			}

			$step->delete();
		}

		$funnel_id = absint( get_request_var( 'funnel' ) );
		$funnel    = new Funnel( $funnel_id );

		/* check if funnel is too big... */
		if ( count( $_POST, COUNT_RECURSIVE ) >= intval( ini_get( 'max_input_vars' ) ) ) {
			return new \WP_Error( 'post_too_big', _x( 'Your [max_input_vars] is too small for your funnel! You may experience odd behaviour and your funnel may not save correctly. Please <a target="_blank" href="http://www.google.com/search?q=increase+max_input_vars+php">increase your [max_input_vars] to at least double the current size.</a>.', 'notice', 'groundhogg' ) );
		}

		$title         = sanitize_text_field( get_request_var( 'funnel_title' ) );
		$args['title'] = $title;

		$status = sanitize_text_field( get_request_var( 'funnel_status', 'inactive' ) );

		//do not update the status to inactive if it's not confirmed
		if ( $status === 'inactive' || $status === 'active' ) {
			$args['status'] = $status;
		}

		$args['last_updated']    = current_time( 'mysql' );
		$args['conversion_step'] = absint( get_request_var( 'conversion-step' ) );

		$funnel->update( $args );

		//get all the steps in the funnel.
		$step_ids = wp_parse_id_list( get_request_var( 'step_ids' ) );

		if ( empty( $step_ids ) ) {
			return new \WP_Error( 'no_steps', 'Please add automation first.' );
		}

		foreach ( $step_ids as $order => $stepId ) {

			$step = new Step( $stepId );

			$step->save();
		}

		/**
		 * Runs after the funnel as been updated.
		 */
		do_action( 'groundhogg/admin/funnel/updated', $funnel );

		return true;

	}

	/**
	 * Add new step via admin ajax
	 */
	public function add_step() {
		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		/* exit out if not doing ajax */
		if ( ! wp_doing_ajax() ) {
			return;
		}

		$step_type = get_request_var( 'step_type' );

		$after_step = new Step( absint( get_request_var( 'after_step' ) ) );

		if ( $after_step->exists() ) {
			$step_order = $after_step->get_order() + 1;
			$funnel_id  = $after_step->get_funnel_id();
		} else {
			$funnel_id = absint( get_post_var( 'funnel_id' ) );
			$funnel    = new Funnel( $funnel_id );

			if ( ! $funnel->exists() ) {
				wp_send_json_error();
			}

			$step_order = 1;
		}

		$elements = Plugin::$instance->step_manager->get_elements();

		$title      = $elements[ $step_type ]->get_name();
		$step_group = $elements[ $step_type ]->get_group();

		$step = new Step();

		$step_id = $step->create( [
			'funnel_id'  => $funnel_id,
			'step_title' => $title,
			'step_type'  => $step_type,
			'step_group' => $step_group,
			'step_order' => $step_order,
		] );

		if ( ! $step_id || ! $step->exists() ) {
			wp_send_json_error();
		}

		ob_start();
		$step->sortable_item();
		$sortable = ob_get_clean();
		ob_start();
		$step->html_v2();
		$settings = ob_get_clean();
		$this->send_ajax_response( [
			'sortable'   => $sortable,
			'settings'   => $settings,
			'id'         => $step->get_id(),
			'after_step' => $after_step,
			'json'       => $step
		] );

		wp_send_json_error();
	}

	public function duplicate_step() {

		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		/* exit out if not doing ajax */
		if ( ! wp_doing_ajax() ) {
			return;
		}

		if ( ! isset( $_POST['step_id'] ) ) {
			wp_send_json_error();
		}

		$step_id = absint( intval( $_POST['step_id'] ) );

		$step = new Step( $step_id );

		if ( ! $step->exists() ) {
			wp_send_json_error();
		}

		$new_step = $step->duplicate();

		ob_start();
		$new_step->sortable_item();
		$sortable = ob_get_clean();
		ob_start();
		$new_step->html_v2();
		$settings = ob_get_clean();
		$this->send_ajax_response( [
			'sortable' => $sortable,
			'settings' => $settings,
			'id'       => $new_step->get_id(),
			'json'     => $new_step
		] );

		wp_send_json_error();
	}

	/**
	 * Ajax function to delete steps from the funnel view
	 */
	public function delete_step() {

		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		/* exit out if not doing ajax */
		if ( ! wp_doing_ajax() ) {
			return;
		}

		$step_id = absint( get_request_var( 'step_id' ) );
		$step    = new Step( $step_id );

		if ( ! $step->exists() ) {
			wp_send_json_error();
		}

		if ( $step->delete() ) {
			wp_send_json_success( [ 'id' => $step_id ] );
		}

		wp_send_json_error();
	}

	public function edit() {
		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		include __DIR__ . '/funnel-editor.php';
	}

	public function add() {
		if ( ! current_user_can( 'add_funnels' ) ) {
			$this->wp_die_no_access();
		}

		include __DIR__ . '/add-funnel.php';
	}

	public function view() {
		if ( ! class_exists( 'Funnels_Table' ) ) {
			include __DIR__ . '/funnels-table.php';
		}

		$funnels_table = new Funnels_Table();

		$funnels_table->views();
		$this->search_form( __( 'Search Funnels', 'groundhogg' ) );
		?>
        <form method="post" class="wp-clearfix">
			<?php $funnels_table->prepare_items(); ?>
			<?php $funnels_table->display(); ?>
        </form>
		<?php
	}

	public function add_to_funnel() {
		if ( ! current_user_can( 'edit_funnels' ) ) {
			$this->wp_die_no_access();
		}

		include __DIR__ . '/add-to-funnel.php';
	}

	public function page() {
		if ( $this->get_current_action() === 'edit' ) {
			$this->edit();

			return;
		}

		parent::page();
	}

	/**
	 * Get template HTML via ajax
	 */
	public function get_funnel_templates_ajax() {
		ob_start();

		$this->display_funnel_templates();
		$html = ob_get_clean();

		$response = array(
			'html' => $html
		);

		wp_send_json( $response );

	}

	public function display_funnel_templates( $args = array() ) {
		$page         = isset( $_REQUEST['p'] ) ? intval( $_REQUEST['p'] ) : '1';
		$args['page'] = $page;

		if ( isset( $_REQUEST['tag'] ) ) {
			$args['tag'] = urlencode( $_REQUEST['tag'] );
		}

		if ( isset( $_REQUEST['s'] ) ) {
			$args['s'] = urlencode( $_REQUEST['s'] );
		}

		$args['category'] = 'templates';


		$products = get_store_products( $args );

		if ( is_object( $products ) && count( $products->products ) > 0 ) {

			foreach ( $products->products as $product ):
				?>
                <div class="postbox" style="margin-right:20px;width: 400px;display: inline-block;">
                    <div class="">
                        <img height="200" src="<?php echo $product->info->thumbnail; ?>" width="100%">
                    </div>
                    <h2 class="hndle"><?php echo $product->info->title; ?></h2>
                    <div class="inside">
                        <p style="line-height:1.2em;  height:3.6em;  overflow:hidden;"><?php echo $product->info->excerpt; ?></p>

						<?php $pricing = (array) $product->pricing;
						if ( count( $pricing ) > 1 ) {

							$price1 = min( $pricing );
							$price2 = max( $pricing );

							?>
                            <a class="button-primary" target="_blank"
                               href="<?php echo $product->info->link; ?>"> <?php printf( _x( 'Buy Now ($%s - $%s)', 'action', 'groundhogg' ), $price1, $price2 ); ?></a>
							<?php
						} else {

							$price = array_pop( $pricing );

							if ( $price > 0.00 ) {
								?>
                                <a class="button-primary" target="_blank"
                                   href="<?php echo $product->info->link; ?>"> <?php printf( _x( 'Buy Now ($%s)', 'action', 'groundhogg' ), $price ); ?></a>
								<?php
							} else {
								?>
                                <a class="button-primary" target="_blank"
                                   href="<?php echo $product->info->link; ?>"> <?php _ex( 'Download', 'action', 'groundhogg' ); ?></a>
								<?php
							}
						}

						?>
                    </div>
                </div>
			<?php endforeach;
		} else {
			?>
            <p style="text-align: center;font-size: 24px;"><?php _ex( 'Sorry, no templates were found.', 'notice', 'groundhogg' ); ?></p> <?php
		}
	}

	/**
	 * @return bool
	 */
	public function is_reporting_enabled() {
		return (bool) get_request_var( 'reporting_on' );
	}
}
