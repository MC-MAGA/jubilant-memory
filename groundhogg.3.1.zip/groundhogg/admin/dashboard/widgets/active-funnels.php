<?php
namespace Groundhogg\Admin\Dashboard\Widgets;
/**
 * Created by PhpStorm.
 * User: atty
 * Date: 11/27/2018
 * Time: 9:13 AM
 */
class Active_Funnels extends Reporting_Widget
{

    /**
     * Load the widget code
     */
    public function widget()
    {
        // TODO: Implement widget() method.
    }

    /**
     * Ge the report ID...
     *
     * @return string
     */
    protected function get_report_id()
    {
        // TODO: Implement get_report_id() method.
    }

    /**
     * Format the data into a chart friendly format.
     *
     * @param $data array
     * @return array
     */
    protected function normalize_data($data)
    {
        // TODO: Implement normalize_data() method.
    }
}