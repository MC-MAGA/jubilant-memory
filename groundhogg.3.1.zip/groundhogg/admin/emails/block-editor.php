<?php

?>
<div id="email-editor" class="gh-fixed-ui">
	<div id="email-block-editor"></div>
</div>
