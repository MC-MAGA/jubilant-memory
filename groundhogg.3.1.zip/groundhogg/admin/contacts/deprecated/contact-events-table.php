<?php

namespace Groundhogg\Admin\Contacts\Tables;

use Groundhogg\Admin\Events;
use function Groundhogg\action_url;
use function Groundhogg\get_db;
use function Groundhogg\get_request_var;
use function Groundhogg\get_url_var;
use Groundhogg\Plugin;
use \WP_List_Table;
use Groundhogg\Event;
use function Groundhogg\html;

/**
 * Contact Events table view
 *
 * This is an extension of the WP_List_Table, it shows the recent or future funnel history of a contact
 * Used in contact-editor.php
 *
 * Shows the name of the funnel, the name of the step, the run date and allows the user to cancel or run the event immediately.
 *
 * Because the data can be past or future, the actual data is set outside of the prepare items function in contact-editor.php
 *
 * @package     Admin
 * @subpackage  Admin/Contacts
 * @author      Adrian Tobey <info@groundhogg.io>
 * @copyright   Copyright (c) 2018, Groundhogg Inc.
 * @license     https://opensource.org/licenses/GPL-3.0 GNU Public License v3
 * @see         WP_List_Table, contact-editor.php
 * @since       File available since Release 0.9
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// WP_List_Table is not loaded automatically so we need to load it in our application
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Contact_Events_Table extends Events\Events_Table {

	/**
	 * The data concerning the contact
	 *
	 * @var array
	 */
	public $data;

	/**
	 * @var string
	 */
	public $status;


	public function __construct( $status = 'waiting' ) {
		$this->status = $status;

		parent::__construct( array(
			'singular' => 'event',     // Singular name of the listed records.
			'plural'   => 'events',    // Plural name of the listed records.
			'ajax'     => false,       // Does this table support ajax?
		) );
	}

	/**
	 * @return array An associative array containing column information.
	 * @see WP_List_Table::::single_row_columns()
	 */
	public function get_columns() {
		$columns = array(
			'funnel'  => _x( 'Funnel', 'Column label', 'groundhogg' ),
			'step'    => _x( 'Step', 'Column label', 'groundhogg' ),
			'time'    => _x( 'Time', 'Column label', 'groundhogg' ),
			'actions' => _x( 'Actions', 'Column label', 'groundhogg' ),
		);

		return apply_filters( 'wpgh_event_columns', $columns );
	}

	public function display_tablenav( $which ) {
		if ( $which === 'top' ):

			?>
			<div class="tablenav <?php echo esc_attr( $which ); ?>">
				<?php $this->extra_tablenav( $which ); ?>
				<br class="clear"/>
			</div>
		<?php
		endif;
	}

	public function extra_tablenav( $which ) {
		$contact_id = absint( get_request_var( 'contact' ) );

		?>
		<div class="alignleft gh-actions">
			<a class="button button-secondary"
			   href="<?php echo admin_url( 'admin.php?page=gh_events&contact_id=' . $contact_id . '&status=' . $this->status ); ?>"><?php _ex( 'View All Events', 'contact_record', 'groundhogg' ); ?></a>
			<?php if ( $this->status === Event::WAITING ): ?>
				<a class="button action"
				   href="<?php echo wp_nonce_url( add_query_arg( [ 'action' => 'process_queue' ], admin_url( 'admin.php?page=gh_events&return_to_contact=' . $contact_id ) ), 'process_queue' ); ?>"><?php _ex( 'Process Events', 'action', 'groundhogg' ); ?></a>
			<?php endif; ?>
		</div>
		<?php
	}

	public function get_views() {
		__return_false();
	}

	/**
	 * @param $event Event
	 * @param string $column_name
	 * @param string $primary
	 *
	 * @return string
	 */
	public function handle_row_actions( $event, $column_name, $primary ) {

		$actions = [];

		if ( $column_name === 'funnel' ) {
			if ( $event->is_funnel_event() ) {
				$actions['edit'] = sprintf( "<a class='edit' href='%s' aria-label='%s'>%s</a>",
					admin_url( 'admin.php?page=gh_funnels&action=edit&funnel=' . $event->get_funnel_id() ),
					esc_attr( _x( 'Edit Funnel', 'action', 'groundhogg' ) ),
					_x( 'Edit Funnel', 'action', 'groundhogg' )
				);
			}

		} else if ( $column_name === 'step' ) {
			if ( $event->is_funnel_event() ) {
				$actions['edit'] = sprintf( "<a class='edit' href='%s' aria-label='%s'>%s</a>",
					admin_url( sprintf( 'admin.php?page=gh_funnels&action=edit&funnel=%d#%d', $event->get_funnel_id(), $event->get_step_id() ) ),
					esc_attr( _x( 'Edit Step', 'action', 'groundhogg' ) ),
					_x( 'Edit Step', 'action', 'groundhogg' )
				);
			}
		}


		return $this->row_actions( apply_filters( 'wpgh_event_row_actions', $actions, $event, $column_name ) );
	}

	/**
	 * @param $event Event
	 *
	 * @return string
	 */
	protected function column_actions( $event ) {
		$actions = array();

		$contact_id = $event->get_contact_id();

		if ( $event->is_waiting() ) {

			$actions['execute_now'] = html()->e( 'a', [
				'href' => action_url( 'execute_now', [
					'page'              => 'gh_events',
					'event'             => $event->get_id(),
					'return_to_contact' => $contact_id
				] ),
			], __( 'Run now', 'groundhogg' ) );
			$actions['delete']      = html()->e( 'a', [
				'href' => action_url( 'cancel', [
					'page'              => 'gh_events',
					'event'             => $event->get_id(),
					'return_to_contact' => $contact_id
				] ),
			], __( 'Cancel', 'groundhogg' ) );
		} else {
			$actions['delete'] = html()->e( 'a', [
				'href' => action_url( 'execute_again', [
					'page'              => 'gh_events',
					'event'             => $event->get_id(),
					'status'            => $this->get_view(),
					'return_to_contact' => $contact_id
				] ),
			], __( 'Run Again', 'groundhogg' ) );
		}

		return $this->row_actions( $actions );
	}

	/**
	 * Prepares the list of items for displaying
	 */
	function prepare_items() {
		$columns  = $this->get_columns();
		$hidden   = array(); // No hidden columns
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );

		$per_page = absint( get_url_var( 'limit', 10 ) );
		$paged    = $this->get_pagenum();
		$offset   = $per_page * ( $paged - 1 );
		$order    = get_url_var( 'order', 'DESC' );
		$orderby  = get_url_var( 'orderby', 'time' );

		$where = [
			'relationship' => "AND",
			[ 'col' => 'status', 'val' => $this->status, 'compare' => '=' ],
			[ 'col' => 'contact_id', 'val' => absint( get_url_var( 'contact' ) ), 'compare' => '=' ],
		];

		$args = array(
			'where'   => $where,
			'limit'   => $per_page,
			'offset'  => $offset,
			'order'   => $order,
			'orderby' => $orderby,
		);

		$this->table = ( $this->status === Event::WAITING ) ? 'event_queue' : 'events';

		$events = get_db( $this->table )->query( $args );
		$total  = get_db( $this->table )->count( $args );

		$this->items = $events;

		// Add condition to be sure we don't divide by zero.
		// If $this->per_page is 0, then set total pages to 1.
		$total_pages = $per_page ? ceil( (int) $total / (int) $per_page ) : 1;

		$this->set_pagination_args( array(
			'total_items' => $total,
			'per_page'    => $per_page,
			'total_pages' => $total_pages,
		) );
	}
}
