<?php

use Groundhogg\Contact;
use function Groundhogg\html;

/**
 * @var $contact Contact
 */
?>
<div id="gh-notes"></div>