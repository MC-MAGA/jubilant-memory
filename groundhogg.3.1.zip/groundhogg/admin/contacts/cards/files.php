<?php

use Groundhogg\Contact;
use function Groundhogg\action_input;
use function Groundhogg\admin_page_url;
use function Groundhogg\html;

/**
 * @var $contact Contact
 */
?>
<button class="gh-button secondary" id="upload-file"><?php _e('Upload files'); ?></button>
<div id="files-here">

</div>
