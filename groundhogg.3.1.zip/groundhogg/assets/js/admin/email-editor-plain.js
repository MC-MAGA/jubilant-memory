( function ($, email) {

  const { input, inputRepeater } = Groundhogg.element
  const { __ } = wp.i18n

  $('#email-form').on('submit', function () {
    $('.spinner').css('visibility', 'visible')

    if (window.self !== window.top) {

      try {
        parent.EmailStep.changesSaved = true
        parent.EmailStep.newEmailId = email.email_id
      }
      catch (e) {
        console.debug(e)
      }
    }
  })

  $('#update_and_test').on('click', function () {
    var test = $('#test-email')

    var test_email = prompt(email.send_test_prompt, test.val())

    if (test_email) {
      test.attr('name', 'test_email')
      test.val(test_email)
    }
  })

  const { custom_headers = [] } = Email.email.meta

  inputRepeater('#custom-headers', {
    rows: Object.keys(custom_headers).map((k) => [k, custom_headers[k]]),
    cells: [
      props => input({
        placeholder: __('Header'),
        name: 'header_key[]',
        ...props,
      }),
      props => input({
        placeholder: __('Value'),
        name: 'header_value[]',
        ...props,
      }),
    ],
  }).mount()

} )(jQuery, Email)
