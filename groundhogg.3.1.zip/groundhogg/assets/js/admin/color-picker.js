( function ($) {
    $(function () {
        $('.wpgh-color').wpColorPicker();
    });
})(jQuery);